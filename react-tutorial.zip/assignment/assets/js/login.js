
$(document).ready(function(){

    // Validate First name
    $("#fn-infoCheck").hide();
    let firstNameError = true;
    $("#firstName").blur(function () {
        validateFirstName();
    });
 
    function validateFirstName() {
        let usernameValue = $("#firstName").val();
        if (usernameValue.length == "") {
            $("#fn-infoCheck").show();
            firstNameError = false;
            return false;
        } else if (usernameValue.length < 3 ) {
            $("#fn-infoCheck").show();
            // $("#info-check").html("**length of username must be between 3 and 10");
            firstNameError = false;
            return false;
        } else {
            $("#fn-infoCheck").hide();
        }
    }

    // last name validation
    $("#ln-infoCheck").hide();
    let lastNameError = true;
    $("#lastName").keyup(function () {
        validateLastName();
    });


    function validateLastName() {
        let lastNameValue = $("#lastName").val();
        if(lastNameValue.length == '') {
            $("#ln-infoCheck").show();
            lastNameError = false;
            return false;
        } else if (lastNameValue.length < 3 ) {
            $("#ln-infoCheck").show();
            $("#ln-infoCheck").html("Last Name must be grater than 3 ")
            lastNameError = false;
            return false;
        } else {
            $("#ln-infoCheck").hide();
        }
    }


    // email
    const email = document.getElementById('email');
    email.addEventListener('blur', () =>  { 
        let regex = 
        /^([_\-\.0-9a-zA-Z]+)@([_\-\.0-9a-zA-Z]+)\.([a-zA-Z]){2,7}$/;

        let mailinfo = email.value;
        if (regex.test(mailinfo)) {
            email.classList.remove('invalid-mail');
            emailError = true;
        } else {
            email.classList.add('valid');
            emailError = false;
        }
    });
    
    
    // Validate Username
    $("#user-infoCheck").hide();
    let userNameError = true;
    $("#userName").blur(function () {
        validateUsername();
    });
 
    function validateUsername() {
        let usernameValue = $("#userName").val();
        if (usernameValue.length == "") {
            $("#user-infoCheck").show();
            userNameError = false;
            return false;
        } else if (usernameValue.length < 3 || usernameValue.length > 10) {
            $("#user-infoCheck").show();
            $("#user-infoCheck").html("**length of username must be between 3 and 10");
            userNameError = false;
            return false;
        } else {
            $("#user-infoCheck").hide();
        }
    }

    // country 
    $("#industry-infoCheck").hide();
    $("#country-infoCheck").hide();

    $("#selectDropBox select").change(function(){
        validateIndustry();
    })

    function validateIndustry() {
        let industryValue = $('#country').val();
        if(industryValue.val() === "") {
            $("#industry-infoCheck").show(); 
            industryError = false;
            return false;
        } else {
            $("#industry-infoCheck").hide();
        }
    }  

        // $('select').on('change', function(){
        //     if($(':submit').is(':disabled')) {
        //         $(':submit').prop('disabled', false);
        //     }
        //     $()
        // })

    // form submit
    $("#logFormButton").click(function () {
        validateFirstName();
        validateLastName();
        validateEmail();
        validateUsername();
        if( 
            usernameError == true && 
            lastNameError == true &&
            emailError == true && 
            validateUsername == true

        ) {
            return true;
        } else {
            return false;
        }

    })

    $("#termsOfUse").click(function(){
        $("#logFormButton").prop("disabled", !$("#termsOfUse").prop("checked"))
    })

})

// select box
/*
$(function () {
 
	var defaultselectbox = $('#industry');
	var numOfOptions = $('#industry').children('option').length;
 
	// hide select tag
	defaultselectbox.addClass('s-hidden');
 
	// wrapping default selectbox into custom select block
	defaultselectbox.wrap('<div class="cusSelBlock"></div>');
 
	// creating custom select div
	defaultselectbox.after('<div class="selectLabel"></div>');
 
	// getting default select box selected value
	$('.selectLabel').text(defaultselectbox.children('option').eq(0).text());
 
	// appending options to custom un-ordered list tag
	var cusList = $('<ul/>', { 'class': 'options'} ).insertAfter($('.selectLabel'));
 
	// generating custom list items
	for(var i=0; i< numOfOptions; i++) {
		$('<li/>', {
		text: defaultselectbox.children('option').eq(i).text(),
		rel: defaultselectbox.children('option').eq(i).val()
		}).appendTo(cusList);
	}
 
	// open-list and close-list items functions
	function openList() {
		for(var i=0; i< numOfOptions; i++) {
			$('.options').children('li').eq(i).attr('tabindex', i).css(
				'transform', 'translateY('+(i*100+100)+'%)').css(
				'transition-delay', i*30+'ms');
		}
	}
 
	function closeList() {
		for(var i=0; i< numOfOptions; i++) {
			$('.options').children('li').eq(i).css(
				'transform', 'translateY('+i*0+'px)').css('transition-delay', i*0+'ms');
		}
		$('.options').children('li').eq(1).css('transform', 'translateY('+2+'px)');
		$('.options').children('li').eq(2).css('transform', 'translateY('+4+'px)');
	}
 
	// click event functions
	$('.selectLabel').click(function () {
		$(this).toggleClass('active');
		if( $(this).hasClass('active') ) {
			openList();
			focusItems();
		}
		else {
			closeList();
		}
	});
 
	$(".options li").on('keypress click', function(e) {
		e.preventDefault();
		$('.options li').siblings().removeClass();
		closeList();
		$('.selectLabel').removeClass('active');
		$('.selectLabel').text($(this).text());
		defaultselectbox.val($(this).text());
		$('.selected-item p span').text($('.selectLabel').text());
	});
	
});*/
 
/*
// form validation
function validateRegister() {
	var country;
 
	country = $('.selectLabel').text();
 
	if (country == 'select') {
	$('#regisErr').removeClass('success').addClass('error').text('* Select country !');
	$('.selectLabel').focus();
	return false;
	}
	else if(country != 'select') {
	$('#regisErr').addClass('success').text('Your country is: '+country);
	return false;
	}
}
*/