$(document).ready(function(){
    $(".navbar-toggler").click(function(){
        $("#navbarCollapse").toggle();
        $(".navbar-toggler").toggleClass("close");
    });

    $(".close").click(function(){
        $(".navbar-collapse").hide();
    })

    // active class based on url
    var current = location.pathname;
    $('.navbar li a').each(function(){
        var $this = $(this);
        // if the current path is like this link, make it active
        if($this.attr('href').indexOf(current) !== -1){
            $this.addClass('active');
        }
    })
    

    // tabs js 
    $('.tab-content').not(':first').hide();
    $('.tab-links a').click(function(){
        $('.tab-content').hide();
        $('.tab-links a').removeClass('active');

        $(this).addClass('active');

        var tab = $(this).data('tab');

        $('#' + tab).show();
    });


});


/*

fetch('../carousel.json')
    .then(function (response) {
        return response.json();
    })
    .then(function (data) {
        appendData(data);
    })
    .catch(function (err) {
        console.log('error: ' + err);
    });


function appendData(data) {
    var mainContainer = document.getElementById("testimonial");
    for (var i = 0; i < data.length; i++) {
        var div = document.createElement("div");
        div.classList.add('testimonial');
        // div.innerHTML = 'Name: ' +  + ' ' + , + ' ' + , + ' ' + ;
        div.innerHTML = ` 
        <div class="row__row container pt-20 pb-20">
            <div class="row__col-md-6 description">
                <h2 class="heading-title">${data[i].headline}</h2>
                <p> ${data[i].caption} </p>
                <a href='${data[i].linkURL}' class="btn btn-primary rounded-pill py-sm-3 px-sm-5">Products</a>
            </div>
            <div class="row__col-md-6 image-holder">
                <img src="${data[i].bgImgURL}" alt="The Last of us" class="carousle-image">
            </div>
        </div>
    `
        mainContainer.appendChild(div);
    }
}
*/



// 