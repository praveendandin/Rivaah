$(document).ready(function(){
    $(".body-overly, .modal-container").hide();

    $(".cards").click(function(){
        $(".body-overly, .modal-container").show();
        // $("body").find('.cards').html(data);
        $('body').addClass('modal-open');
    })

    $("#modalClose, .body-overly").click(function(){
        $(".body-overly, .modal-container").hide();
        $('body').removeClass('modal-open');
    });

});

$(document).keydown(function(e){
    if(e.keyCode == 27) {
        $(".body-overly, .modal-container").hide();
        $('body').removeClass('modal-open');
    }
})