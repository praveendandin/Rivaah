const footerTemplate = document.createElement('footerTemplate')

footerTemplate.innerHTML = `
    <footer class="footer">
        <div class="container footer-items d-flex">
            <span>&copy;  2023</span>

            <span>            
             <a href="/">Home</a>
             <a href="#">About </a>
             <a href="../">Service</a>
             <a href="#">Products</a>
             <a href="../contact">Contact</a>
             </span>
        </div>
    </footer>
`

document.body.appendChild(footerTemplate)